import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 
import java.awt.*; 
import java.awt.event.*; 
import javax.swing.*; 
import javax.swing.event.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class dualSerialMonitor extends PApplet {


 
 
 


static JFrame f; 

JLabel label1, label2;
static JComboBox serialList1, serialList2; 
static JComboBox baud1, baud2; 
static JButton connectButton1, connectButton2;
static JTextArea logText1, logText2; 
static JTextField sendText1, sendText2;
static JButton reflesSerialListButton;

static JButton sendButton1, sendButton2;

Serial serial1, serial2;
String msg1, msg2;

long serialListAutoLoader;
String[] serialList;

public void setup() { 
  surface.setVisible(false);

  GuiListener listener = new GuiListener(this);
  serialList = Serial.list();

  JPanel p1 = new JPanel();
  p1.setLayout(null);
  {
    // create labels 
    label1 = new JLabel("LOG1"); 
    label1.setForeground(Color.red); 
    //l1.setMinimumSize(new Dimension(20, 20));
    label1.setBounds(20, 20, 500, 20);
    
    serialList1 = new JComboBox(serialList); 
    //c1.addItemListener(listener); 
    serialList1.addActionListener(listener);
    //c1.setMinimumSize(new Dimension(20, 20));
    serialList1.setBounds(20, 50, 350, 20);

    baud1 = new JComboBox(BAUD_LIST); 
    //baud1.addActionListener(listener);
    baud1.setBounds(370, 50, 100, 20);

    connectButton1 = new JButton(BUTTON_LABEL_CONNECT);
    connectButton1.setBounds(475, 50, 90, 20);
    connectButton1.addActionListener(listener);
  
    {
      JLabel l = new JLabel("Recv"); 
      l.setForeground(Color.red); 
      l.setBounds(20, 80, 500, 20);
      p1.add(l);
    }

    logText1 = new JTextArea();
    logText1.setLineWrap(true);
    logText1.setPreferredSize(new Dimension(450, 400));
    //t1.setMinimumSize(new Dimension(100, 100));
    logText1.setBounds(20, 110, 540, 550);
    
    {
      JLabel l = new JLabel("Send(Press Enter Key)"); 
      l.setForeground(Color.red); 
      l.setBounds(20, 670, 500, 20);
      p1.add(l);
    }
    
    sendText1 = new JTextField();
    sendText1.setBounds(15, 690, 550, 20);
    sendText1.setBackground(Color.gray);
    sendText1.addKeyListener(listener);
    sendText1.setEnabled(false);
    
    sendButton1 = new JButton("Send(without Enter Code)");
    sendButton1.setBounds(20, 715, 200, 20);
    sendButton1.setEnabled(false);
    sendButton1.addActionListener(listener); 

    p1.add(label1);
    p1.add(serialList1);
    p1.add(baud1);
    p1.add(connectButton1);
    p1.add(logText1);
    p1.add(sendText1);
    p1.add(sendButton1);
  }
  
  {
    label2 = new JLabel("LOG2"); 
    label2.setForeground(Color.blue); 
    //l2.setMinimumSize(new Dimension(20, 20));
    label2.setBounds(600, 20, 450, 20);

    serialList2 = new JComboBox(serialList); 
    //c2.addItemListener(listener);
    serialList2.addActionListener(listener);
    //c2.setMinimumSize(new Dimension(20, 20));
    serialList2.setBounds(600, 50, 350, 20);

    baud2 = new JComboBox(BAUD_LIST); 
    //baud2.addActionListener(listener);
    baud2.setBounds(950, 50, 100, 20);
    
    connectButton2 = new JButton(BUTTON_LABEL_CONNECT);
    connectButton2.setBounds(1055, 50, 90, 20);
    connectButton2.addActionListener(listener); 
  
    {
      JLabel l = new JLabel("Recv"); 
      l.setForeground(Color.blue); 
      l.setBounds(600, 80, 500, 20);
      p1.add(l);
    }

    logText2 = new JTextArea();
    logText2.setLineWrap(true);
    logText2.setPreferredSize(new Dimension(450, 400));
    //t2.setMinimumSize(new Dimension(100, 100));
    //logText2.setEnabled(false);
    logText2.setBounds(600, 110, 540, 550);
    
    {
      JLabel l = new JLabel("Send(Press Enter Key)"); 
      l.setForeground(Color.blue); 
      l.setBounds(600, 670, 500, 20);
      p1.add(l);
    }

    sendText2 = new JTextField();
    sendText2.setBounds(595, 690, 550, 20);
    sendText2.setBackground(Color.gray);
    sendText2.addKeyListener(listener);
    sendText2.setEnabled(false);

    sendButton2 = new JButton("Send(without Enter Code)");
    sendButton2.setBounds(600, 715, 200, 20);
    sendButton2.setEnabled(false);
    sendButton2.addActionListener(listener); 

    reflesSerialListButton = new JButton("Reflesh Serial List");
    reflesSerialListButton.setBounds(20, 745, 1120, 20);
    reflesSerialListButton.addActionListener(listener); 

    p1.add(label2);
    p1.add(serialList2);
    p1.add(baud2);
    p1.add(connectButton2);
    p1.add(logText2);
    p1.add(sendText2);
    p1.add(sendButton2);
    p1.add(reflesSerialListButton);
  }
  
  f = new JFrame("Dual Serial Monitor"); 
  f.add(p1);
  f.setSize(W_WIDTH, W_HEIGHT); 
  f.setVisible(true); 
}

public void draw() {
}

public void serialEvent(Serial _serialPort) {
  String str = _serialPort.readString();//Until('\r');
  if (_serialPort.equals(serial1)) {
    logText1.setText(logText1.getText() + str);
  }
  else if (_serialPort.equals(serial2)) {
    logText2.setText(logText2.getText() + str);
  }
}

public void refleshSerialList() {
  if (serialList != Serial.list()) {
    serialList = Serial.list();

    {
      DefaultComboBoxModel model = new DefaultComboBoxModel( serialList );
      String selectedItem = (String)serialList1.getSelectedItem();
      serialList1.setModel(model);
      if (selectedItem != null) {
        serialList1.setSelectedItem(selectedItem);
      }
    }
  
    {
      DefaultComboBoxModel model = new DefaultComboBoxModel( serialList );
      String selectedItem = (String)serialList2.getSelectedItem();
      serialList2.setModel(model);
      if (selectedItem != null) {
        serialList2.setSelectedItem(selectedItem);
      }
    }
  }
}
final int W_WIDTH = 1170;
final int W_HEIGHT = 800;
final String[] BAUD_LIST = {"9600", "19200", "115200"};

final String BUTTON_LABEL_CONNECT = "Connect";
final String BUTTON_LABEL_RELEASE = "Release";
class GuiListener implements ItemListener, ChangeListener, ActionListener, KeyListener {
  PApplet pa;

  GuiListener(PApplet _pa) {
    pa = _pa;
  }

  public void itemStateChanged(ItemEvent e) { 
    /*if (e.getSource() == c1) {
     println(c1.getSelectedItem() + " selected");
     }
     else if (e.getSource() == c2) {
     println(c2.getSelectedItem() + " selected");
     }*/
  }

  public void stateChanged(ChangeEvent e) {
    /*if (e.getSource() == b1) {
     println("b1 changed");
     }
     else if (e.getSource() == b2) {
     println("b2 changed");
     }*/
  }
  
  public void keyPressed(java.awt.event.KeyEvent e) {
    if(e.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
      if (e.getSource() == sendText1) {
        if (serial1 != null) {
          serial1.write(sendText1.getText() + "\r\n");
          sendText1.setText("");
        }
      }
      else if (e.getSource() == sendText2) {
        if (serial2 != null) {
          serial2.write(sendText2.getText() + "\r\n");
          sendText2.setText("");
        }
      }
    }
  }

  public void keyReleased(java.awt.event.KeyEvent e) {
    if(e.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
    }
  }
  
  public void keyTyped(java.awt.event.KeyEvent e) {
    if(e.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
    }
  }

  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == serialList1) {
      println("serialList1 " + serialList1.getSelectedItem() + " selected");
    } else if (e.getSource() == serialList2) {
      println("serialList2 " + serialList2.getSelectedItem() + " selected");
    }
    // LOG1の接続にチャレンジ
    else if (e.getSource() == connectButton1) {
      if (connectButton1.getText().equals(BUTTON_LABEL_CONNECT)) {
        try {
          println(" => try to connect ");         
          String targetPort = (String)serialList1.getSelectedItem();
          int baudRate = Integer.parseInt((String)baud1.getSelectedItem());
          if (serial1 == null) {
            serial1 = new Serial(pa, targetPort, baudRate);

            label1.setText("LOG1(Connect to: " + targetPort + ")");

            connectButton1.setText(BUTTON_LABEL_RELEASE);
            //connectButton1.setEnabled(false);
            
            sendText1.setEnabled(true);
            sendText1.setBackground(Color.white);
            sendButton1.setEnabled(true);
          }
        }
        catch (Exception e2) {
          logText1.setText(logText1.getText() + "\r\n[error]" + e2);
        }
      }
      else {
        if (serial1 != null) {
          try {
            serial1.stop();
            serial1.dispose();
            serial1 = null;
  
            label1.setText("LOG1");
  
            connectButton1.setText(BUTTON_LABEL_CONNECT);
            
            sendText1.setEnabled(false);
            sendText1.setBackground(Color.gray);
            sendButton1.setEnabled(false);
          }
          catch (Exception e2) {
            logText1.setText(logText1.getText() + "\r\n[error]" + e2);
          }
        }
      }
    }
    // LOG2の接続にチャレンジ
    else if (e.getSource() == connectButton2) {
      if (connectButton2.getText().equals(BUTTON_LABEL_CONNECT)) {
        try {
          println(" => try to connect ");         
          String targetPort = (String)serialList2.getSelectedItem();
          int baudRate = Integer.parseInt((String)baud2.getSelectedItem());
          if (serial2 == null) {
            serial2 = new Serial(pa, targetPort, baudRate);

            label2.setText("LOG2(Connect to: " + targetPort + ")");

            connectButton2.setText(BUTTON_LABEL_RELEASE);
            //connectButton2.setEnabled(false);
            
            sendText2.setEnabled(true);
            sendText2.setBackground(Color.white);
            sendButton2.setEnabled(true);
          }
        }
        catch (Exception e2) {
          logText2.setText(logText2.getText() + "\r\n[error]" + e2);
        }
      }
      else {
        if (serial2 != null) {
          try {
            serial2.stop();
            serial2.dispose();
            serial2 = null;
  
            label2.setText("LOG2");
  
            connectButton2.setText(BUTTON_LABEL_CONNECT);
            
            sendText2.setEnabled(false);
            sendText2.setBackground(Color.gray);
            sendButton2.setEnabled(false);
          }
          catch (Exception e2) {
            logText2.setText(logText2.getText() + "\r\n[error]" + e2);
          }
        }
      }
    }
    else if (e.getSource() == sendButton1) {
      if (serial1 != null) {
        serial1.write(sendText1.getText());
        sendText1.setText("");
      }
    }
    else if (e.getSource() == sendButton2) {
      if (serial2 != null) {
        serial2.write(sendText2.getText());
        sendText2.setText("");
      }
    }
    else if (e.getSource() == reflesSerialListButton) {
      refleshSerialList();
    }
  }
}  
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "dualSerialMonitor" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
